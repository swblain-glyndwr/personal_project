"""Generic streaming transformation utilities."""

from pyspark.sql import SparkSession, DataFrame
import pyspark.sql.functions as F
from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql.types import LongType, TimestampType, ArrayType, BooleanType


def get_kafka_streaming_source(spark: SparkSession, connection_helper) -> DataFrame:
    """
    Creates a streaming DataFrame from Kafka/EventHub source.

    Args:
        spark: SparkSession object
        connection_helper: Connection helper with get_options() method

    Returns:
        Streaming DataFrame with raw Kafka messages
    """
    options = connection_helper.get_options("inbound")
    df = spark.readStream.format("kafka").options(**options).load()
    return df


def write_to_kafka_sink(df: DataFrame, connection_helper, query_name: str) -> None:
    """
    Writes streaming DataFrame to Kafka/EventHub sink.

    Args:
        df: Streaming DataFrame to write
        connection_helper: Connection helper with get_options() method
        query_name: Name for the streaming query
    """
    options = connection_helper.get_options("outbound")
    (df.writeStream.format("kafka").queryName(query_name).options(**options).start())


def decode_kafka_message(stream: DataFrame) -> DataFrame:
    """
    Decodes Kafka message value and parses JSON payload.

    Args:
        stream: Raw Kafka streaming DataFrame
        schema: StructType defining the JSON payload structure

    Returns:
        DataFrame with parsed JSON payload in 'payload_json' column
    """

    schema = StructType(
        [
            StructField("event_type", StringType(), False),
            StructField("fullvisitorid", StringType(), False),
            StructField("visitid", StringType(), False),
            StructField("MASID", StringType(), False),
            StructField("RPID", LongType(), False),
            StructField("event_timestamp", TimestampType(), False),
            StructField("ProductSKU", ArrayType(StringType()), False),
            StructField("IsMasterRPID", BooleanType(), False),
            StructField("user_agent", StringType(), False),
        ]
    )

    return stream.select(F.decode("value", "utf-8").alias("payload")).select(
        F.from_json(F.col("payload"), schema).alias("payload_json")
    )
