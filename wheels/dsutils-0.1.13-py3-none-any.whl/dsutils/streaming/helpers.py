"""General helper functions for streaming data processing and validation."""

import re
import collections


SEGMENT_EXCEPTIONS = ["NONE", "PPL"]
DEFAULT_PATTERN = r"^[A-Za-z]{2}\d{1,2}_[A-Za-z\d]{1,}"


def check_segment(seg: str, pattern: str = DEFAULT_PATTERN) -> tuple:
    """
    Validates a single segment of a delimited identifier string.

    Args:
        seg: Single segment string to validate
        pattern: Regex pattern for validation (default: 2 letters,
            1-2 digits, underscore, 1+ alphanumeric)

    Returns:
        Tuple of (is_valid: bool, error_message: str)
    """
    if seg in SEGMENT_EXCEPTIONS:
        return (True, "")

    if "_" not in seg:
        return (False, f"Segment {seg} doesn't contain '_'")

    if re.match(pattern, seg):
        return (True, "")
    else:
        return (False, f"Segment {seg} doesn't meet pattern requirements: {pattern}")


def check_valid_identifier(
    identifier: str,
    delimiter: str = "|",
    segment_pattern: str = DEFAULT_PATTERN,
    allow_empty: bool = True,
) -> bool:
    """
    Validates a delimited identifier string by checking all segments.

    Args:
        identifier: Delimited string to validate
            (e.g., "PH1_ABC|SS2_DEF|SC3_GHI")
        delimiter: Segment delimiter (default: "|")
        segment_pattern: Regex pattern for individual segment validation
        allow_empty: Whether empty/whitespace identifiers are valid

    Returns:
        True if valid

    Raises:
        ValueError: If validation fails, with details of all invalid segments
    """
    if not identifier or not identifier.strip():
        if allow_empty:
            return True
        else:
            raise ValueError("Identifier is empty")

    segments = identifier.split(delimiter)
    results = collections.OrderedDict()

    for seg in segments:
        results[seg] = check_segment(seg, segment_pattern)

    if not all([r[0] for k, r in results.items()]):
        failures = [r[1] for k, r in results.items() if not r[0]]
        fail_msg = "\n".join(failures)
        raise ValueError(fail_msg)

    return True
