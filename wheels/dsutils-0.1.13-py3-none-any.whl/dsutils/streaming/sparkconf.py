"""Spark configuration utilities for optimized structured streaming."""

from pyspark.sql import SparkSession


def configure_streaming_spark(
    spark: SparkSession,
    enable_rocksdb: bool = True,
    enable_changelog: bool = True,
    enable_async_checkpoint: bool = False,
) -> None:
    """
    Configures Spark session with optimized settings for structured streaming.

    Args:
        spark: Active SparkSession to configure
        enable_rocksdb: Enable RocksDB-based state management for better
            performance with large state
        enable_changelog: Enable changelog checkpointing to reduce checkpoint
            duration and end-to-end latency
        enable_async_checkpoint: Enable asynchronous state checkpointing
            (not recommended with autoscaling clusters)
    """
    if enable_rocksdb:
        spark.conf.set(
            "spark.sql.streaming.stateStore.providerClass",
            "com.databricks.sql.streaming.state.RocksDBStateStoreProvider",
        )

    if enable_changelog:
        spark.conf.set(
            "spark.sql.streaming.stateStore.rocksdb.changelogCheckpointing.enabled",
            "true",
        )

    if enable_async_checkpoint:
        spark.conf.set(
            "spark.databricks.streaming.statefulOperator.asyncCheckpoint.enabled",
            "true",
        )
