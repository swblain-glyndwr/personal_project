import logging
import sys
from pathlib import Path


def configure_logging(
    log_level: int | str = logging.INFO, log_filepath: str = "", quiet_py4j: bool = True
) -> None:
    """
    Configure logging output to stdout.

    Arguments:
        log_level - Minimum logging level to capture.
        log_filepath - Optional path to log file.
        quiet_py4j - Suppress py4j logging below ERROR (due to verbosity).
    """
    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)

    # Remove any existing hadnlers to avoid duplicate logs
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)

    formatter = logging.Formatter(
        fmt="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)

    if log_filepath:
        log_path = Path(log_filepath)
        file_handler = logging.FileHandler(log_path)
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)

    if quiet_py4j:
        py4j_logger = logging.getLogger("py4j")
        py4j_logger.setLevel(logging.ERROR)

    return None


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger instance for the specified module.

    Arguments:
        name - Name of the logging module (typically __name__).

    Returns:
        Configured logging instance.
    """
    return logging.getLogger(name)
