import base64
import ast
import gspread as gs
from pyspark.sql import DataFrame

from dsutils.etl import build_spark_schema
from dsutils.dbc import get_dbutils, get_spark
from dsutils.logtools import get_logger


logger = get_logger(__name__)


def gcp_conn(scope: str, key: str):
    """
    Returns `gspread` connection object.
    """
    logger.debug("Getting gspread connection object")
    file = get_dbutils().secrets.get(scope=scope, key=key)
    decoded = base64.b64decode(file.encode("utf-8")).decode("utf-8")
    service_account_dict = ast.literal_eval(decoded)
    return gs.service_account_from_dict(service_account_dict)


def spark_df_from_sheets(
    url: str,
    worksheet_name: str,
    gcp_scope: str,
    gcp_key: str,
    schema: list[list[str]] = [],
) -> DataFrame:
    """
    Function to read from Google Sheets to Spark dataframe.
    Current functionality limited to importing all columns as strings.

    Arguments:
        url - URL of Google Sheet
        worksheet_name - Name of worksheet to be read
        gcp_scope - Scope with which to create gcp connection object
        gcp_key - Key with which to create gcp connection object
        schema - List of lists representing schema to be read
            e.g. `[["ID","string","not null"],["Name","string","nullable"]]`
    """
    google_sheet = gcp_conn(scope=gcp_scope, key=gcp_key).open_by_url(url)
    worksheet = google_sheet.worksheet(worksheet_name)

    logger.debug(f"Getting records from sheet {worksheet_name} at url {url}")
    if schema:
        df = get_spark().createDataFrame(
            worksheet.get_all_records(), build_spark_schema(schema)
        )
    else:
        df = get_spark().createDataFrame(worksheet.get_all_records())

    return df
