from argparse import ArgumentParser
from typing import Dict, Any

from dsutils.logtools import get_logger


logger = get_logger(__name__)

VALID_ENVS = ["dev", "preprod", "prod"]


class UniversalArgParser(ArgumentParser):
    """
    Universal argument parser Class for handling Databricks task parameters
    passed. This class inherits from widely used argparse library and
    treats all paramters passed as unknown and then dynamically adds these as
    arguments which can then be accessed elsewhere in the script.

    There are a handful of expected (yet optional) parameters which will
    have some aditional pre-processing steps added to them when passed.

    Expected args/params for pre-processing:
        --jobname -> when passed we attempt to infer the job_env and client
                     add add these as indipendent args.
    """

    def __init__(self):
        """
        Initialise parser from parent class and create args attribute
        to store args. Then process args with _parse_args().
        """
        super().__init__(allow_abbrev=False)
        self.args = None
        self._parse_args()

    def _parse_args(self) -> None:
        """
        Called in __init__ to ensure _parse_args() is only called once when
        the object is instanciated through calling get_job_parser().
        """
        if self.args is None:
            # Get all arguments, treating all as unknown
            _, unknown = self.parse_known_args()
            self.args = {}

            # Process all arguments
            i = 0
            while i < len(unknown):
                if unknown[i].startswith("--"):
                    arg_name = unknown[i]
                    if i + 1 < len(unknown) and not unknown[i + 1].startswith("--"):
                        # Handle value arguments (--arg value)
                        self.args[arg_name] = unknown[i + 1]
                        i += 2
                    else:
                        # Handle flag arguments (--flag)
                        self.args[arg_name] = True
                        i += 1
                else:
                    # Skip non-argument values
                    i += 1

        self._preprocess_jobname()
        self._preprocess_env()
        self._preprocess_username()

        return self.args

    def _preprocess_env(self) -> None:
        """
        Standard pre-processing steps performed when '--env' argument
        is passed.
        """
        env = self.args.get("--env")
        if not env:
            logger.info("No --env provided (defaulting to 'dev')")
            self.args["--env"] = "dev"
        else:
            assert env.lower() in VALID_ENVS, f"--env not in {VALID_ENVS}"
            logger.info(f"--env provided: '{env}'")
            self.args["--env"] = env.lower()

    def _preprocess_username(self) -> None:
        """
        Standard pre-processing steps performed when '--username' argument
        is passed.
        """
        username = self.args.get("--username")
        if not username:
            logger.debug("No --username provided, returning empty string")
            self.args["--username"] = ""

    def _preprocess_jobname(self) -> None:
        """
        Standard pre-processing steps performed when '--jobname'
        perameter is passed.

        Method attempts to infer 'job_env' and 'client' from
        '--jobname'. Defaults to job_env=dev and client=None
        when unable to infer.
        """
        # Process jobname if it exists
        jobname = self.args.get("--jobname")
        # Set default values
        job_env = "dev"
        client = None

        if jobname:
            # Split jobname by underscore to extract components
            jlist = jobname.split("_")
            i = 0
            # Check if the first component indicates environment
            if jlist and jlist[0] == "dev":
                job_env = "dev"
                i += 1
            else:
                job_env = "prod"
            # Extract client if there are enough components
            if len(jlist) > i + 2:
                client = f"{jlist[i + 1]}_{jlist[i + 2]}"
            # Validate client for non-dev jobs
            if job_env != "dev" and not client:
                msg = "WARNING: Cannot run as job without specified client"
                logger.debug(msg)
                assert self.args["client"], msg

        # Store extracted information if they are not already passed in
        if not self.has_arg("--client"):
            self.args["--client"] = client
        if not self.has_arg("--job_env"):
            self.args["--job_env"] = job_env

    def get_all_args(self) -> Dict[str, Any]:
        """
        Returns all arguments.
        """
        return self.args

    def has_arg(self, name: str) -> bool:
        """
        Check if an argument was provided.
        """
        return name in self.args

    def get_arg(self, name: str) -> Any:
        """
        Get a specific argument value with an optional default.
        """
        return self.args.get(name)

    def get_typed_arg(self, name: str, arg_type: type) -> Any:
        """
        Get an argument with type conversion. Useful for ensuring numerical
        parameters are properly converted from strings to their expected type.
        """
        value = self.get_arg(name)
        if value is not None:
            if arg_type is bool:
                if isinstance(value, str):
                    lower_value = value.lower()
                    if lower_value in ["true", "True", "1", "on"]:
                        return True
                    elif lower_value in ["false", "False", "0", "off"]:
                        return False
                    else:
                        try:
                            return arg_type(value)
                        except (ValueError, TypeError) as e:
                            logger.debug(e)
                            return e
                else:
                    return bool(value)
            else:
                try:
                    return arg_type(value)
                except (ValueError, TypeError) as e:
                    logger.debug(e)
                    return e
        return value


def get_job_parser():
    """Function to ensure only one instance exists at any given time."""
    logger.debug("Creating UniversalArgParser Instance.")
    return UniversalArgParser()


def get_universal_parser():
    """Alias for get_job_parser for backward compatibility."""
    logger.debug("Creating UniversalArgParser Instance.")
    return UniversalArgParser()
