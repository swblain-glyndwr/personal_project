import re
import yaml
from pathlib import Path
from pyspark.sql.utils import AnalysisException

from dsutils.dbc import get_spark
from dsutils.logtools import get_logger

logger = get_logger(__name__)


def generate_data_catalogue(
        tables_dict: dict,
        output_filename: str = "data_catalogue.yml",
        output_dir: str = None) -> str:
    """
    Generates a data catalogue YAML file from a dictionary of table references.

    Arguments:
        tables_dict - Dictionary mapping table reference names to locations
            e.g. {"table_ref_name": "catalog.schema.table_name"}
        output_filename - Name of the output YAML file
            (default: data_catalogue.yml)
        output_dir - Directory to write the output file
            (default: current working directory)

    Returns:
        Path to the generated YAML file

    Example:
        tables = {
            "svoc_cust": "marketingdata_prod.warehouse.svoccust_hist",
            "theme_transitions": (
                "marketingdata_prod.ds_sandbox."
                "next_uk_nextads_theme_transitions"
            )
        }
        generate_data_catalogue(tables)
    """

    def _parse_describe_extended_df(describe_df):
        """
        Parses the complex output of 'DESCRIBE TABLE EXTENDED' into a dict,
        including Primary Keys and other detailed metadata.

        Arguments:
            describe_df - PySpark DataFrame from DESCRIBE TABLE EXTENDED

        Returns:
            Dictionary containing columns, partition_by, primary_keys,
            table_type, created_time, provider, and table_properties
        """
        rows = [row.asDict() for row in describe_df.collect()]

        def _find_section_start(section_name, rows_list):
            try:
                return [i for i, r in enumerate(rows_list)
                        if r['col_name'] == section_name][0]
            except IndexError:
                return len(rows_list)

        partition_start = _find_section_start('# Partition Information',
                                              rows)
        detailed_start = _find_section_start('# Detailed Table Information',
                                             rows)
        constraints_start = _find_section_start('# Constraints', rows)
        first_section_start = min(partition_start,
                                  detailed_start,
                                  constraints_start)

        column_strings = [
            f"{r['col_name']}:{r['data_type']}:True"
            for r in rows[:first_section_start]
            if r['col_name'] and not r['col_name'].startswith('#')
        ]

        partitions = [
            r['col_name'] for r in rows[partition_start + 1:detailed_start]
            if r['col_name'] and not r['col_name'].startswith('#')
        ]

        details_rows = rows[detailed_start + 1:constraints_start]
        details_dict = {r['col_name']: r['data_type']
                        for r in details_rows if r['col_name']}

        pk_list = []
        constraints_rows = rows[constraints_start + 1:]
        for r in constraints_rows:
            if r['data_type'] and r['data_type'
                                    ].strip().startswith('PRIMARY KEY'):
                match = re.search(r'\((.*?)\)', r['data_type'])
                if match:
                    pk_string = match.group(1).replace('`', '')
                    pk_list = [col.strip() for col in pk_string.split(',')]
                    break

        return {
            "columns": column_strings,
            "partition_by": partitions or ["Not Partitioned"],
            "primary_keys": pk_list or ["Not Defined"],
            "table_type": details_dict.get("Type"),
            "created_time": details_dict.get("Created Time"),
            "provider": details_dict.get("Provider"),
            "table_properties": details_dict.get("Table Properties")
        }

    def _get_table_metadata(table_location: str, reference: str):
        """
        Retrieves metadata for a table or parquet file. Tries SQL format first,
        then falls back to parquet format.

        Arguments:
            table_location - Full path to SQL table or parquet location
            reference - Reference name for the table

        Returns:
            Dictionary containing schema_details and format, or None if failed
        """
        spark = get_spark()

        try:
            describe_df = spark.sql("DESCRIBE TABLE EXTENDED "
                                    f" {table_location}")
            schema_info = _parse_describe_extended_df(describe_df)
            logger.info(
                "Successfully retrieved metadata for '{reference}' "
                "as SQL table")
            return {
                "schema_details": schema_info,
                "format": "sql"
            }
        except AnalysisException as e:
            logger.warning(f"Could not read '{reference}' as sql table")
            logger.debug(f"SQL table error details: {e}", exc_info=True)

        try:
            df = spark.read.parquet(table_location)
            column_strings = [
                f"{f.name}:{f.dataType.simpleString()}:{f.nullable}"
                for f in df.schema.fields
            ]
            logger.info(
                f"Successfully retrieved metadata for '{reference}' "
                "as parquet")
            return {
                "schema_details": {
                    "columns": column_strings,
                    "table_type": "Parquet Files"
                },
                "format": "parquet"
            }
        except Exception as e:
            logger.warning(f"Could not read '{reference}' as parquet")
            logger.debug(f"Parquet read error details: {e}", exc_info=True)
            return None

    logger.info("Starting data catalogue generation")
    if output_dir is None:
        output_dir = Path.cwd()
    else:
        output_dir = Path(output_dir)

    output_path = output_dir / output_filename

    # Delete existing file if it exists
    if output_path.exists():
        logger.info(f"Deleting existing catalogue: {output_path}")
        output_path.unlink()

    catalogue_data = []

    # Process tables from the dictionary
    for reference, location in tables_dict.items():
        logger.info(f"Processing table '{reference}': {location}")
        metadata = _get_table_metadata(location, reference)

        if metadata:
            entry = {
                "reference": reference,
                "table_name": location,
                "schema_details": metadata["schema_details"]
            }
            catalogue_data.append(entry)
        else:
            logger.warning(
                f"Skipping '{reference}' - could not retrieve metadata")

    # Write the catalogue to YAML
    logger.info(f"Writing catalogue to: {output_path}")
    with open(output_path, 'w') as f:
        yaml.dump(catalogue_data,
                  f,
                  sort_keys=False,
                  default_flow_style=False,
                  indent=2)

    logger.info(f"Data catalogue generation complete! Output: {output_path}")
    return str(output_path)
