import importlib
import os
from pyspark.sql import SparkSession
from databricks.connect import DatabricksSession

from dsutils.logtools import get_logger


logger = get_logger(__name__)


def get_spark():
    """
    Get `spark` (for the active `SparkSession`). Enables code compatibility
    across Databricks browser and DatabricksConnect session
    (e.g. via VS Code). Note, when using in the Databricks UI, a spark session
    will be active by default, however for cross-compatibility between the
    Databricks UI and local development environments, it is recommended that
    users create a spark object using `configure_spark()` at the beginning of
    their main script.

    Usage:
        spark.table(...)
            - Works via Databricks browser, but not via Databricks Connect
        get_spark().table(...)
            - Works via Databricks browser and Databricks connect
    """
    return SparkSession.getActiveSession()


def parse_databricks_local_env() -> dict:
    """
    Parses environment variables from .databricks/.databricks.env file created
    by Databricks extension for VS Code.

    Returns:
        Dictionary of Databricks environment variables. If .databricks.env
        file not found, returns empty dictionary.
    """
    db_env_paths = [
        '.databricks/.databricks.env',
        '.databricks.env'
        ]

    while db_env_paths:
        db_env_file = db_env_paths.pop(0)
        if os.path.isfile(db_env_file):
            with open(db_env_file) as f:
                lines = f.readlines()
            return {x.split('=')[0]: x.split('=')[1].strip() for x in lines}

    return dict()


def configure_spark() -> SparkSession:
    """
    Auto-configure Spark Session based on current environment. Configuring
    Spark in this way enables more flexibility with respect to development
    environments.

    Returns:
        SparkSession object (either Spark Session or Spark Connect Session).
        Exception raised if Spark Session cannot be established.
    """
    logger.info('Configuring Spark Session')
    active_session = SparkSession.getActiveSession()

    if active_session is not None:
        logger.info('Utilising active Spark Session')
        return active_session

    logger.info('No active Spark Session found - building new Session')
    cluster_key = 'DATABRICKS_CLUSTER_ID'
    try:
        cluster_id = os.environ[cluster_key]
        logger.info('Building Spark Session using Cluster ID in os.environ')
    except KeyError:
        cluster_id = parse_databricks_local_env()[cluster_key]
        logger.info(
            'Building Spark Session using Cluster ID in .databricks.env')
    except Exception as e:
        logger.error('Unable to establish Spark Session (no Cluster ID found)')
        raise e

    return DatabricksSession.builder.clusterId(cluster_id).getOrCreate()


def get_dbutils():
    """
    Gets `dbutils` for the active `SparkSession`; enables code compatibility
    across Databricks browser and DatabricksConnect session
    (e.g. via VS Code).

    Usage:
        dbutils.secrets.get(...)
            - Works via Databricks browser, but not via Databricks Connect
        get_dbutils().secrets.get(...)
            - Works via Databricks browser and Databricks Connect
    """
    if importlib.util.find_spec("databricks.connect") is not None:
        from pyspark.dbutils import DBUtils
        return DBUtils(get_spark())
    else:
        import IPython
        return IPython.get_ipython().user_ns["dbutils"]


def get_display(df):
    """
    Gets `display` for the active `SparkSession`; enables code compatibility
    across Databricks browser and DatabricksConnect session
    (e.g. via VS Code).

    Usage:
        df.display()
            - Works via Databricks browser, but not via Databricks Connect
        get_display(df)
            - Works via Databricks browser and Databricks Connect
    """
    if importlib.util.find_spec("databricks.connect") is not None:
        from IPython.display import display
        return display(df)
    else:
        return df.display()
