"""Streaming utilities for real-time data processing."""

from .connections import EventHubConnectionHelper
from .sparkconf import configure_streaming_spark
from .transformations import (
    get_kafka_streaming_source,
    write_to_kafka_sink,
    decode_kafka_message,
)
from .helpers import check_segment, check_valid_identifier
