"""EventHub and Kafka connection utilities for structured streaming."""

import sys
import os

# Add parent directory to path for imports
parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

try:
    from dbc import get_dbutils as dbc_get_dbutils
    from logtools import get_logger

except ImportError:
    from dsutils.dbc import get_dbutils as dbc_get_dbutils
    from logtools import get_logger


logger = get_logger(__name__)


class EventHubConnectionHelper:
    """
    Manages Azure EventHub Kafka connection configuration for streaming.
    Handles OAuth authentication with Azure EventHub using service principal
    credentials and provides optimized connection parameters for both
    inbound and outbound streaming operations.
    """

    def __init__(
        self,
        target: str,
        db_secretscope: str,
        SPN_secretscope: str,
        eventhub_namespace: str,
        inbound_topic: str,
        outbound_topic: str,
        checkpoint_path: str,
    ):
        setattr(self, "target", target)
        setattr(self, "db_secretscope", db_secretscope)
        setattr(self, "SPN_secretscope", SPN_secretscope)
        setattr(self, "eventhub_namespace", eventhub_namespace)
        setattr(self, "inbound_topic", inbound_topic)
        setattr(self, "outbound_topic", outbound_topic)
        setattr(self, "checkpoint_path", checkpoint_path)

        target_options = ["dev", "pp", "prod"]
        if self.target not in target_options:
            raise Exception(
                f'target should be one of {" ,".join(target_options)}'
            )

    def get_secret(self, secretscope, key):
        """Retrieves a secret from Databricks secret scope."""
        dbutils = dbc_get_dbutils()
        return dbutils.secrets.get(secretscope, key)

    def get_options(self, direction: str) -> dict:
        """
        Builds Kafka connection options for Azure EventHub streaming.

        Args:
            direction: Either "inbound" (reading) or "outbound" (writing)

        Returns:
            Dictionary of Kafka configuration options optimized for
            Azure EventHub
        """
        direction_options = ["inbound", "outbound"]

        if direction not in direction_options:
            raise Exception(
                f'direction should be one of '
                f'{", ".join(direction_options)}'
            )
        utarget = self.target.capitalize()

        tenant_id = self.get_secret(
            self.db_secretscope, f"DataPlatform-{utarget}-TenantId"
        )

        app_id = self.get_secret(
            self.SPN_secretscope,
            "Databricks-Spn-MarketingData-ClientId",
        )

        client_secret = self.get_secret(
            self.SPN_secretscope,
            "Databricks-Spn-MarketingData-ClientSecret",
        )

        event_hubs_topic = (
            self.outbound_topic if direction == "outbound"
            else self.inbound_topic
        )

        sasl_config = (
            "kafkashaded.org.apache.kafka.common.security."
            "oauthbearer.OAuthBearerLoginModule "
            f'required clientId="{app_id}" '
            f'clientSecret="{client_secret}" '
            f'scope="https://{self.eventhub_namespace}.'
            'servicebus.windows.net/.default" '
            'ssl.protocol="SSL";'
        )

        options = {
            "kafka.bootstrap.servers": (
                f"https://{self.eventhub_namespace}."
                "servicebus.windows.net:9093"
            ),
            "kafka.sasl.jaas.config": sasl_config,
            "kafka.sasl.oauthbearer.token.endpoint.url": (
                f"https://login.microsoft.com/{tenant_id}/oauth2/v2.0/token"
            ),
            "kafka.security.protocol": "SASL_SSL",
            "kafka.sasl.mechanism": "OAUTHBEARER",
            "kafka.sasl.login.callback.handler.class": (
                "kafkashaded.org.apache.kafka.common.security."
                "oauthbearer.OAuthBearerLoginCallbackHandler"
            )
        }

        options["subscribe"] = event_hubs_topic
        options["kafka.metadata.max.age.ms"] = 180000
        options["connections.max.idle.ms"] = 180000

        if direction == "inbound":
            options["startingOffsets"] = "latest"
            options["session.timeout.ms"] = 30000
            options["max.poll.interval.ms"] = 300000
            options["socket.keepalive.enable"] = True
            options["heartbeat.interval.ms"] = 3000

        if direction == "outbound":
            dbutils = dbc_get_dbutils()
            dbutils.fs.rm(self.checkpoint_path, True)
            options["topic"] = event_hubs_topic
            options["checkpointLocation"] = self.checkpoint_path
            options["max.request.size"] = 1000000
            options["retries"] = 1
            options["request.timeout.ms"] = 60000
            options["metadata.max.idle.ms"] = 180000
            options["linger.ms"] = 500
            options["delivery.timeout.ms"] = (
                (options["request.timeout.ms"] + options["linger.ms"])
                * options["retries"]
            )

        logger.info(f"EventHub connection options for {direction}: {options}")
        return options
