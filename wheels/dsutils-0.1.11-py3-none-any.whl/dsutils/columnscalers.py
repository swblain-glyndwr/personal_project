from pyspark.sql import Column, Window
from pyspark.sql import functions as F

from dsutils.logtools import get_logger


logger = get_logger(__name__)


def subtract_mean(
        column: Column,
        partition_by: list[str] = [],
        rebase_to_zero: bool = False) -> Column:
    """
    Subtracts column mean from column by optional partition.

    Arguments:
        column - PySpark `Column` to process
        partition_by - List of column names to partition by
        rebase_to_zero - Sets global minimum of column to zero
    """
    logger.debug(f'Subtracting mean from {column} by {partition_by}')
    if partition_by:
        w = Window.partitionBy([F.col(p) for p in partition_by])
    else:
        w = Window.partitionBy(F.lit(1))

    new_column = (column - F.mean(column).over(w))

    w_all = Window.partitionBy(F.lit(1))
    if rebase_to_zero:
        new_column = new_column - F.min(new_column).over(w_all)

    return new_column


def z_score(
        column: Column,
        partition_by: list[str] = []) -> Column:
    """
    Z-Score (based on sample stdev) of column by optional partition.
    Z = (x-mean(x))/std(x)

    Arguments:
        column -- PySpark `Column` to process
        partition_by -- List of column names to partition by
    """
    logger.debug(f'Calculating z-score from {column} by {partition_by}')
    if partition_by:
        w = Window.partitionBy([F.col(p) for p in partition_by])
    else:
        w = Window.partitionBy(F.lit(1))

    new_column = (subtract_mean(column, partition_by)/F.std(column).over(w))

    return new_column


def percentile_scaler(
        column: Column,
        percentiles: list[float] = [0.0, 1.0],
        partition_by: list[str] = [],
        approximate: bool = False) -> Column:
    """
    Percentile-based scaler that will scale [lower,upper] to range (0,1).
    Setting [lower,upper] percentiles to [0.0, 1.0] yields min-max scaling.
    _Note: This function is more computationally expensive than a dedicated
    min-max scaler._

    Arguments:
        column -- PySpark `Column` to process
        percentiles -- [lower,upper] percentiles to use for scaling
        partition_by -- List of column names to partition by
        approximate -- Toggle `F.percentile_approx` (with default accuracy)
    """
    msg_len_check = 'percentile list must contain exactly two floats'
    assert len(percentiles) == 2, msg_len_check

    pc_fn = F.percentile_approx if approximate else F.percentile

    logger.debug(f'Percentile scaling {column} by {partition_by}' +
                 f' using percentile anchors {percentiles}' +
                 f' (percentile func: {pc_fn.__name__})')

    pc_min, pc_max = float(percentiles[0]), float(percentiles[1])

    if partition_by:
        w = Window.partitionBy([F.col(p) for p in partition_by])
    else:
        w = Window.partitionBy(F.lit(1))

    column_rebased = column - pc_fn(column, pc_min).over(w)
    column_upper = pc_fn(column, pc_max).over(w)
    column_lower = pc_fn(column, pc_min).over(w)
    column_range = column_upper - column_lower
    new_column = column_rebased / column_range

    return new_column
