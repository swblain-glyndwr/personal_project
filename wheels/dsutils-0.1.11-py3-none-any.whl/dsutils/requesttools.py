import asyncio
import aiohttp
import time

from dsutils.logtools import get_logger


logger = get_logger(__name__)


class AsyncRequestProcessor:
    """
    A class to handle asynchronous processing of HTTP requests.
    """

    def __init__(
            self,
            base_url: str,
            max_concurrent_requests: int = 10,
            timeout: int = 30):
        """
        Initialize the AsyncRequestProcessor.

        Args:
            base_url: The base URL for all requests
            max_concurrent_requests: Maximum number of concurrent requests
            timeout: Timeout in seconds for each request
        """
        self.base_url = base_url
        self.semaphore = asyncio.Semaphore(max_concurrent_requests)
        self.timeout = aiohttp.ClientTimeout(total=timeout)

    async def process_tokens(
            self,
            method: str,
            tokens: list[str],
            endpoint: str = "") -> list[tuple]:
        """
        Process a list of tokens concurrently using async requests.

        Args:
            tokens: List of tokens to process
            method: HTTP method to use
            endpoint: API endpoint

        Returns:
            List of tuples containing (token, response_data)
        """

        start_time = time.time()
        logger.info(f"Starting async processing of {len(tokens):,} requests")

        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            tasks = [
                self._process_single_token(session, token, method, endpoint)
                for token in tokens
            ]
            results = await asyncio.gather(*tasks, return_exceptions=True)

        # Filter out and log exceptions
        filtered_results = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                logger.error(
                    f"Error processing token {tokens[i]}: {str(result)}"
                    )
                filtered_results.append((tokens[i], None))
            else:
                filtered_results.append(result)

        elapsed = time.time() - start_time
        logger.info(
            f"Completed processing {len(tokens):,} requests" +
            f" in {elapsed:.2f} seconds")

        return filtered_results

    async def _process_single_token(
            self,
            session,
            token: str,
            method: str,
            endpoint: str) -> tuple:
        """
        Process a single ID with rate limiting via semaphore.
        """
        async with self.semaphore:
            return await self._make_request(session, token, method, endpoint)

    async def _make_request(
            self,
            session,
            token: str,
            method: str,
            endpoint: str = "") -> tuple:
        """
        Make HTTP request for a specific token.
        """
        url = self.base_url.rstrip("/")
        if "{token}" in url:
            url = url.format_map({"token": token})
        if endpoint:
            if "{endpoint}" in url:
                url = url.format_map({"endpoint": endpoint})
            else:
                url = f"{url}/{endpoint}"
        else:
            url = f"{url}/{token}"
        logger.debug(f"Concatenated url for {method} request: {url}")

        # -- Functionality not yet tested
        # params = {}
        # if params_func:
        #     params = params_func(token)

        try:
            logger.debug(f"Making request for token: {token}")
            method = method.upper()

            if method == "GET":
                async with session.get(url) as response:
                    response.raise_for_status()
                    data = await response.json()
                    return (token, data)
            # -- Functionality not yet tested
            # elif method == "POST":
                # async with session.post(
                    # url, headers=headers, json=params) as response:
                    # response.raise_for_status()
                    # data = await response.json()
                    # return (token, data)
            # elif method == "PUT":
                # async with session.put(
                    # url, headers=headers, json=params) as response:
                    # response.raise_for_status()
                    # data = await response.json()
                    # return (token, data)
            # elif method == "DELETE":
                # async with session.delete(url, headers=headers) as response:
                    # response.raise_for_status()
                    # data = await response.json()
                    # return (token, data)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")

        except aiohttp.ClientResponseError as e:
            logger.error(
                f"Request error for token {token}: {e.status} - {e.message}"
                )
            raise
        except aiohttp.ClientError as e:
            logger.error(f"Client error for token {token}: {str(e)}")
            raise
        except asyncio.TimeoutError:
            logger.error(f"Request timeout for token {token}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error for token {token}: {str(e)}")
            raise


# For direct usage in other modules:
def process_requests(
        method: str,
        tokens: list[str],
        base_url: str,
        endpoint: str = "",
        max_concurrent: int = 10) -> list[tuple]:
    """
    Helper function to use the AsyncRequestProcessor without dealing with
    async syntax. Be conscious of rate limits on the API you are querying
    if increasing concurrency of requests.

    Args:
        method: HTTP method
        tokens: List of tokens to process
        base_url: Base URL for requests
        endpoint: API endpoint
        max_concurrent: Maximum concurrent requests
        -- DEV - Add functionality for request headers and params

    Usage:
        Input forms to batch queries to same endpoint:
        With `token` placeholder,
        base_url = 'https://www.site.co.uk/v1/products/{token}
        tokens = ['id1', 'id2', ...]
        Without `token` placeholder also acceptable,
        base_url = 'https://www.site.co.uk/v1/products/
        tokens = ['id1', 'id2', ...]
        `endpoint` can also be parameterised for flexibility,
        base_url = 'https://www.site.co.uk/v1/{endpoint}
        tokens = ['id1', 'id2', ...]
        endpoint = 'products'

        To query a batch of queries to different urls, supply:
        base_url = '{token}'
        tokens = ['url1', 'url2', ...]

    Returns:
        List of (token, response_data) tuples
    """
    async def _run():
        processor = AsyncRequestProcessor(
            base_url=base_url,
            max_concurrent_requests=max_concurrent
        )
        return await processor.process_tokens(
            method=method,
            tokens=tokens,
            endpoint=endpoint)

    return asyncio.run(_run())
