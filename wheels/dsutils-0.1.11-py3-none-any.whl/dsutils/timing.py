from collections.abc import Callable
import functools
import time

from dsutils.logtools import get_logger


logger = get_logger(__name__)


def timer(func: Callable) -> Callable:
    """
    A decorator that logs the execution time of the decorated function.

    Args:
        func: The function to be timed

    Returns:
        The wrapped function with timing functionality
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        elapsed_time = end_time - start_time
        logger.info(
            f"Function '{func.__name__}' executed in" +
            f" {elapsed_time:.4f} seconds"
            )
        return result
    return wrapper


def async_timer(func: Callable) -> Callable:
    """
    A decorator that logs the execution time of the decorated async function.

    Args:
        func: The async function to be timed

    Returns:
        The wrapped async function with timing functionality
    """
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        start_time = time.time()
        result = await func(*args, **kwargs)
        end_time = time.time()
        elapsed_time = end_time - start_time
        logger.info(
            f"Async function '{func.__name__}' executed in" +
            f" {elapsed_time:.4f} seconds"
            )
        return result
    return wrapper
